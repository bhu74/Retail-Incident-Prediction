# Retail Incident Forecast Scorer

### Local Use

- **With Docker**
  - To build the scorer execute inside `/src` folder:
    ```bash
    $ sudo docker build -t rif-scorer .
    ```

  - To run execute:
    ```bash
    $ sudo docker run --rm \
        -v /path/to/ground_truth_folder:/gt \
        -v /path/to/solution_folder:/sol \
        -v /path/to/result_folder:/result \
          rif-scorer \
            /gt/ground_truth.csv \
            /sol/solution_file.csv \
            /result/result_file.txt
    ```

    Note that for `-v /path/to/folder:/mount/path` arguments you may use paths
    relative to the current working directory as so:
    `-v "$(pwd)/foloder:/mount/path"`

- **Without Docker**
  - The scorer is a simple NodeJS script, thus you may prefer to build and run
    it without Docker. Just execute inside `/src`:
    ```bash
    $ npm install
    $ npm start -- /path/to/ground_truth_folder /path/to/solution.csv /path/to/result.txt
    ```
