const fs = require('fs');
const path = require('path');

const csvParse = require('csv-parse/lib/sync');

let [,, groundTruthFile, solutionFile, resultFile] = process.argv;

groundTruthFile = path.resolve(process.cwd(), groundTruthFile);
solutionFile = path.resolve(process.cwd(), solutionFile);
resultFile = path.resolve(process.cwd(), resultFile);

function readCsv(filename) {
  const rawData = fs.readFileSync(filename, 'utf8');
  return csvParse(rawData, { from_line: 2 });
}

function readIncidentCounts(filename) {
  const data = readCsv(filename);
  const res = {};
  res.x = new Set();
  data.forEach(([
    locationId,
    incidentType,
    numIncidentsStr,
    averageIncidentDurationStr,
  ]) => {
    if (!res[locationId]) res[locationId] = {};
    else if (res[locationId][incidentType]) {
      throw Error(
        `Duplicated location & incident pair: ${locationId}, ${incidentType}`,
      );
    }
    res.x.add(`${locationId}:${incidentType}`);
    res[locationId][incidentType] = {
      count: parseFloat(numIncidentsStr),
      avDuration: averageIncidentDurationStr
        ? parseFloat(averageIncidentDurationStr) : 0,
    };
  });
  return res;
}

const gtData = readIncidentCounts(groundTruthFile);
const solData = readIncidentCounts(solutionFile);

let countSum = 0;
let countScore = 0.0;
let durationScore = 0.0;

Object.keys(gtData).forEach((locationId) => {
  Object.keys(gtData[locationId]).forEach((incidentType) => {
    const gt = gtData[locationId] && gtData[locationId][incidentType];
    const sol = solData[locationId] && solData[locationId][incidentType];

    if (!sol) {
      throw Error(
        `Solution misses the record: ${locationId}:${incidentType}`,
      );
    }
    if (!gt.avDuration) sol.avDuration = 0.0;
    if (!sol.avDuration) sol.avDuration = 0.0;

    if (sol.count >= 0.0 && sol.avDuration >= 0.0) {
      countScore += Math.exp(
        -(2.0 * Math.abs(gt.count - sol.count)) / (1 + gt.count + sol.count),
      );
      if (gt.avDuration) {
        durationScore += Math.exp(
          -(2.0 * Math.abs(gt.avDuration - sol.avDuration))
            / (1 + gt.avDuration + sol.avDuration),
        );
      } else durationScore += 1.0;
    } else {
      throw Error(
        `Invalid record: ${locationId}:${incidentType}; count: ${sol.count}; avDuration: ${sol.avDuration}`,
      );
    }
    countSum += 1;
    solData.x.delete(`${locationId}:${incidentType}`);
  });
});

if (solData.x.size) {
  throw Error(
    `Solution contains unexpected records, e.g.: ${
      solData.x.values().next().value
    }`,
  );
}

countScore *= 100.0 / countSum;
durationScore *= 100.0 / countSum;
const score = 0.8 * countScore + 0.2 * durationScore;

console.log('Score breakdown:');
console.log('  incident count score    =', countScore);
console.log('  incident duration score =', durationScore);
console.log('  overall score           =', score);

fs.writeFileSync(resultFile, score);
